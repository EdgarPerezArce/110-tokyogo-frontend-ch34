

function Footer() {
    return (
        <div className="footer">
            <label>All Imaginary Rights Reserved for ToKyoGo©</label>
        </div>
    );
}

export default Footer;