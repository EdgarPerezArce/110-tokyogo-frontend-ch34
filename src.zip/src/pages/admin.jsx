import AdminProducts from "../components/adminProducts";
import AdminCouponCodes from "../components/aminCouponCodes";
import "./admin.css";

function Admin(){
    return (
        <div className="admin">
            <h1>Store Administration</h1>
            <div className="parent">

                <AdminProducts></AdminProducts>

                <AdminCouponCodes></AdminCouponCodes>
            </div>
        </div>


    );
}

export default Admin;